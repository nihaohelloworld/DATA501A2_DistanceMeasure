## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
# Conditional installation code
if (!requireNamespace("DATA501A2DM", quietly = TRUE)) {
  devtools::install_github("nihaohelloworld/DATA501A2_DistanceMeasure")
}

## -----------------------------------------------------------------------------
library(DATA501A2DM)

# Fit a linear model
lm_model <- lm(mpg ~ wt + hp, data = mtcars)

# Plot Cook's Distance
plot_influence_measure(mtcars, lm_model, method = "cooks")

# Plot DFFITS
plot_influence_measure(mtcars, lm_model, method = "dffits")

# Plot Hadi's Influence Measure
plot_influence_measure(mtcars, lm_model, method = "hadi")

